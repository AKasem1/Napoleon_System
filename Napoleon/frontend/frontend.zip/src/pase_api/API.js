const pase_admin_apis = "http://localhost:2025/admin";
/* =========== students =========== */
const get_students = `${pase_admin_apis}/getStudent`;

import React, { useEffect, useState } from "react";
import "./Form.css";
import { Link } from "react-router-dom";
import axios from "axios";
import Swal from "sweetalert2";
import Header from "../Home/header/Header";
import Footer from "../Footer";

export default function Form() {
  const [name, setname] = useState("");
  const [phone, setphone] = useState("");
  const [parentPhone, setparentPhone] = useState("");
  const [grade, setgrade] = useState("الصف");
  const [code, setcode] = useState("");
  const [handelgrade, setHandelgrade] = useState("");
  const [groups, setgroups] = useState([{}]);
  const [selectedGroup, setSelectedGroup] = useState("");
  const [payment, setpayment] = useState("");

  useEffect(() => {
    if (grade !== "الصف") {
      gethandelgrade();
    }
  }, [grade]);

  const gethandelgrade = () => {
    axios
      .get(`http://localhost:2025/admin/getGroup/${grade}`)
      .then((res) => {
        setHandelgrade(res.data);
        setgroups(res.data);
        if (res.status === 201) {
        }
      })
      .catch((err) => {
        if (err.response) {
        }
      });
  };
  const handleGroupChange = (value) => {
    setSelectedGroup(value);
  };
  ///////////////////////////////
  // fetch data
  function Submit(e) {
    e.preventDefault();
    axios
      .post("http://localhost:2025/admin/addStudent", {
        name: name,
        phone: phone,
        parentPhone: parentPhone,
        grade: grade,
        group: selectedGroup,
        code: code,
        payment: payment,
      })

      .then((t) => {
        console.log(t);
        Swal.fire({
          title: "عملية ناجحة ",
          text: "تم تسجيل الطالب بنجاح ",
          icon: "success",
        });
        setname("");
        setphone("");
        setparentPhone("");
        setcode("");
        setSelectedGroup("");
        setgrade("الصف");
        setpayment("");
      })
      .catch((err) => {
        console.log(err, "error");
        Swal.fire({
          icon: "error",
          title: "خطأ",
          text: "يوجد خطأ في تسجيل البيانات",
        });
      });
  }

  return (
    <>
      <div className="background-form">
        <Header />

        <form className="student-form" onSubmit={Submit}>
          <p className="title">تسجيل الطالب </p>

          <div className="flex">
            <label>
              <input
                className="input"
                type="text"
                placeholder=""
                required
                value={name}
                onChange={(e) => setname(e.target.value)}
              />
              <span>أسم الطالب</span>
            </label>
          </div>
          <div>
            <label>
              <input
                className="input"
                type="text"
                placeholder=""
                required
                value={phone}
                onChange={(e) => setphone(e.target.value)}
              />
              <span>الرقم الشخصي </span>
            </label>
          </div>

          <label>
            <input
              className="input"
              type="text"
              placeholder=""
              required
              value={parentPhone}
              onChange={(e) => setparentPhone(e.target.value)}
            />
            <span>رقم ولي الأمر </span>
          </label>

          <label>
            <input
              className="input"
              type="text"
              placeholder=""
              required
              value={code}
              onChange={(e) => setcode(e.target.value)}
            />
            <span>الكود</span>
          </label>

          <label>
            <select
              className="m-auto choise text-center"
              value={grade}
              style={{ color: "white" }}
              onChange={(e) => setgrade(e.target.value)}
            >
              <option value="الصف" disabled>
                الصف
              </option>
              <option value="الصف الأول الثانوي">الصف الأول الثانوي</option>
              <option value="الصف الثاني الثانوي">الصف الثاني الثانوي</option>
              <option value="الصف الثالث الثانوي">الصف الثالث الثانوي</option>
            </select>
          </label>
          <label>
            <select
              value={selectedGroup}
              style={{ color: "white" }}
              className="m-auto choise text-center"
              name="group"
              onChange={(e) => handleGroupChange(e.target.value)}
            >
              <option value="" disabled>
                اختر المجموعة
              </option>
              {groups.map((g, ind) => (
                <option key={ind} value={g.name}>
                  {g.name}
                </option>
              ))}
            </select>
          </label>
          <label>
            <select
              className="m-auto choise text-center"
              style={{ color: "white" }}
              name="payment"
              onChange={(e) => setpayment(e.target.value)}
            >
              <option value={payment}>
                الدفع
                {payment}
              </option>
              <option value="دفع بالحصة">دفع بالحصة</option>
              <option value="دفع بالشهر">دفع بالشهر</option>
            </select>
          </label>

          <button style={{ borderRadius: "20px" }} className="submit">
            تسجيل
          </button>
          <Link
            to={"/home"}
            className="submit text-decoration-none text-center"
            style={{ borderRadius: "20px" }}
          >
            الرجوع الي الصفحة الرئيسية
          </Link>
        </form>
      </div>
    </>
  );
}

import React from "react";
import "./Search.css";

export default function Search() {
  return (
    <div className="search0">
      <input
        type="text1"
        name="text"
        placeholder="Search 'كود الطالب'"
        class="input"
      />
    </div>
  );
}

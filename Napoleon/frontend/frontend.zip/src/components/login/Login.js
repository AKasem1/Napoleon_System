import React, { useState } from "react";
import "./login.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import bg2 from "../../pic/nap2.png";
import bg from "../../pic/napleon photo.png";
import bg3 from "../../pic/temple.png";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [accept, setAccept] = useState(false);
  const [err, setErr] = useState(false);
  const nav = useNavigate();

  const api = "http://localhost:2025/admin/login";

  function Submit(e) {
    e.preventDefault();
    setAccept(true);
    axios
      .post(api, {
        username: username,
        password: password,
      })
      .then((res) => {
        const token = res.data.token;
        console.log(res);
        localStorage.setItem("token", token);
        nav("/home");
      })
      .catch((error) => {
        if (error.response.status === 422) {
          setErr(true);
          console.log(err);

          setAccept(true);
        }
      });
  }

  return (
    <>
      <div className="flex back_ground-login ">
        <img src={bg2} className="back_ground22" alt="" />
        <img src={bg} className="back_ground11" alt="" />
        <img src={bg3} className="back_ground33" alt="" />
      </div>

      <div>
        <div className="login-box">
          <form onSubmit={Submit}>
            <div className="user-box">
              <input
                type="text"
                placeholder=""
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
              <label>Username</label>
            </div>
            <div className="user-box">
              <input
                type="password"
                placeholder=""
                value={password}
                required
                onChange={(e) => setPassword(e.target.value)}
              />
              <label>Password</label>
            </div>
            <center>
              <button className="button1">Login</button>
            </center>
            {accept && err && (
              <p className="error mx-5 danger">
                PassWord or username are wornge
              </p>
            )}
          </form>
        </div>
      </div>
    </>
  );
}

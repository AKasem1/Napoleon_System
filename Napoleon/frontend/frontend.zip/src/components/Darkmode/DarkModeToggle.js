const DarkLightModeToggler = ({ isDarkMode = false }) => {

};

export default DarkLightModeToggler;
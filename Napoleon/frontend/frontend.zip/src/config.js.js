const api = "http://localhost:2025";

export default api;
